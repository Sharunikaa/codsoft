from flask import Flask, render_template, request, redirect
import mysql.connector

app = Flask(__name__)

# Connect to MySQL database
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="sharu1310",
    database="contact"
)
cursor = conn.cursor()

# Function to create contacts table if not exists
def create_table():
    cursor.execute('''CREATE TABLE IF NOT EXISTS contacts (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        name VARCHAR(100) NOT NULL,
                        phone VARCHAR(20),
                        email VARCHAR(100),
                        address VARCHAR(255)
                    )''')
    conn.commit()

create_table()

@app.route('/')
def index():
    # Retrieve all contacts from the database
    cursor.execute("SELECT * FROM contacts")
    contacts = cursor.fetchall()
    return render_template('index.html', contacts=contacts)

@app.route('/add_contact', methods=['GET', 'POST'])
def add_contact():
    if request.method == 'POST':
        name = request.form['name']
        phone = request.form['phone']
        email = request.form['email']
        address = request.form['address']

        # Insert new contact into the database
        cursor.execute("INSERT INTO contacts (name, phone, email, address) VALUES (%s, %s, %s, %s)",
                       (name, phone, email, address))
        conn.commit()

        return redirect('/')
    return render_template('add_contact.html')

@app.route('/search_contact', methods=['POST'])
def search_contact():
    query = request.form['query']
    cursor.execute("SELECT * FROM contacts WHERE name LIKE %s", ('%' + query + '%',))
    results = cursor.fetchall()
    return render_template('search_contact.html', results=results)

@app.route('/update_contact', methods=['POST'])
def update_contact():
    old_name = request.form['old_name']
    new_name = request.form['new_name']
    new_phone = request.form['phone']
    new_email = request.form['email']
    new_address = request.form['address']

    # Update contact in the database
    cursor.execute("UPDATE contacts SET name=%s, phone=%s, email=%s, address=%s WHERE name=%s",
                   (new_name, new_phone, new_email, new_address, old_name))
    conn.commit()

    return redirect('/')

@app.route('/delete_contact/<int:contact_id>', methods=['POST'])
def delete_contact(contact_id):
    if request.method == 'POST':
        cursor.execute("DELETE FROM contacts WHERE id=%s", (contact_id,))
        conn.commit()
        return redirect('/')
    return render_template('delete_contact.html')

if __name__ == '__main__':
    app.run(debug=True)
