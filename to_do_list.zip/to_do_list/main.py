import tkinter as tk
from tkinter import messagebox

class TodoListApp:
    def __init__(self, master):
        self.master = master
        self.master.title("To-Do List App")
        self.master.geometry("400x400")

        self.tasks = []

        self.task_entry = tk.Entry(self.master, width=30)
        self.task_entry.pack(pady=10)

        self.add_button = tk.Button(self.master, text="Add Task", command=self.add_task)
        self.add_button.pack(pady=5)

        self.task_frame = tk.Frame(self.master)
        self.task_frame.pack(pady=10)

        self.populate_tasks()

    def add_task(self):
        task = self.task_entry.get()
        if task:
            self.tasks.append({"task": task, "done": False})
            self.update_listbox()
            self.task_entry.delete(0, tk.END)
        else:
            messagebox.showwarning("Warning", "Please enter a task.")

    def delete_task(self, index):
        del self.tasks[index]
        self.update_listbox()

    def update_listbox(self):
        for widget in self.task_frame.winfo_children():
            widget.destroy()

        for i, task in enumerate(self.tasks):
            var = tk.BooleanVar(value=task["done"])
            checkbox = tk.Checkbutton(self.task_frame, variable=var)
            checkbox.grid(row=i, column=0, sticky="w")
            label = tk.Label(self.task_frame, text=task["task"])
            label.grid(row=i, column=1, sticky="w")
            delete_button = tk.Button(self.task_frame, text="Delete", command=lambda index=i: self.delete_task(index))
            delete_button.grid(row=i, column=2, padx=5)

    def populate_tasks(self):
        self.update_listbox()

def main():
    root = tk.Tk()
    app = TodoListApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
